const quadrado = document.getElementById("quadrado");
const ctx = quadrado.getContext("2d");




const img = new Image();
img.src = "curso-de-ferias-python-na-FEI-2025_Prof-Victor-Varella.jpeg";
img.onload = () => {
drawImageAtMousePosition(0,0);
}

function drawImageAtMousePosition(x,y){
    const imgWidth = 50;
    const imgHeight = 50;
    const posX = x - imgWidth / 2;
    const posY = y - imgHeight / 2;


const maxX = quadrado.width - imgWidth;
const maxY = quadrado.height - imgHeight;
const constrainedX = Math.min(Math.max(0, posX), maxX);
const constrainedY = Math.min(Math.max(0, posY), maxY);

ctx.clearRect(0, 0, quadrado.width, quadrado.height)

ctx.drawImage(img, constrainedX, constrainedY, imgWidth, imgHeight)
}

quadrado.addEventListener('mousemove',(event) => {
    const rect = quadrado.getBoundingClientRect();
    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;
    drawImageAtMousePosition(mouseX, mouseY)
});

// function animacao(){
//     ctx.clearRect(0,0,300,300)
//     bola.desenha();
//     requestAnimationFrame(animacao)
// }
// animacao();
// document.addEventListener('mousemove',function(evento){
//     let rect = canvas.getBoundingClientRect();
//     let x_mouse = evento.clientX - rect.left;
//     let y_mouse = evento.clientY - rect.top;
//     console.log(x_mouse,y_mouse);
//     bola.x = x_mouse;
//     bola.y = y_mouse;
// })
