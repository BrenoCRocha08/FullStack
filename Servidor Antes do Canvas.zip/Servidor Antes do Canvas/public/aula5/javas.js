window.alert("Bem vindo ao site de adivinhação");



let numeroSecreto = Math.floor(Math.random() * 10);

function verificar() {
    let valor = Number(document.getElementById("numero").value);
    let resultado = document.getElementById("resultado");

   
    if (isNaN(valor)) {
        resultado.innerText = "Digite um número válido!";
        return;
    }


    if (valor === numeroSecreto) {
        resultado.innerText = "🎉 Acertou!";
    } else if (valor > numeroSecreto) {
        resultado.innerText = "📉 O número é menor!";
        
      
        document.getElementById("container")
        .style.setProperty("background-color", "red");

    } else {
        resultado.innerText = "📈 O número é maior!";
        
       
        document.getElementById("container")
        .style.setProperty("background-color", "red");
    }
}
