let casinha = document.getElementById("casinha");
let ctx1 = casinha.getContext("2d");


ctx1.beginPath();
ctx1.lineWidth = 1;
ctx1.fillStyle = "yellow";
ctx1.strokeStyle = "yellow";
ctx1.arc(470,150,55,0,2*Math.PI);
ctx1.fill();
ctx1.stroke();
ctx1.closePath();


ctx1.beginPath();
ctx1.fillStyle = "grey";
ctx1.strokeStyle = "black";
ctx1.strokeRect(0,480,600,600);
ctx1.fillRect(0,480,600,600);
ctx1.closePath();


ctx1.beginPath();
ctx1.fillStyle = "brown";
ctx1.strokeStyle = "black";
ctx1.strokeRect(225,320,140,160);
ctx1.fillRect(225,320,140,160);
ctx1.closePath();


ctx1.beginPath();
ctx1.fillStyle = "skyblue";
ctx1.strokeStyle = "black";
ctx1.strokeRect(235,350,45,45);
ctx1.fillRect(235,350,45,45);

ctx1.strokeRect(310,350,45,45);
ctx1.fillRect(310,350,45,45);
ctx1.closePath();


ctx1.beginPath();
ctx1.fillStyle = "maroon";
ctx1.strokeStyle = "black";
ctx1.strokeRect(276,396,35,85);
ctx1.fillRect(276,396,35,85);
ctx1.closePath();


ctx1.beginPath();
ctx1.fillStyle = "brown";
ctx1.strokeStyle = "black";
ctx1.fillRect(488,450,30,85);
ctx1.strokeRect(488,450,30,85);
ctx1.closePath();

ctx1.beginPath();
ctx1.fillStyle = "green";
ctx1.strokeStyle = "green";
ctx1.arc(500,420,44,0,2*Math.PI);
ctx1.fill();
ctx1.stroke();
ctx1.closePath();


ctx1.beginPath();
ctx1.fillStyle = "brown";
ctx1.strokeStyle = "black";
ctx1.fillRect(129,420,30,85);
ctx1.strokeRect(129,420,30,85);
ctx1.closePath();

ctx1.beginPath();
ctx1.fillStyle = "green";
ctx1.strokeStyle = "green";
ctx1.arc(139,390,44,0,2*Math.PI);
ctx1.fill();
ctx1.stroke();
ctx1.closePath();


ctx1.beginPath();
ctx1.fillStyle = "cornflowerblue";
ctx1.strokeStyle = "cornflowerblue";
ctx1.arc(0,480,63,1*Math.PI,2*Math.PI);
ctx1.fill();
ctx1.stroke();
ctx1.closePath();

ctx1.beginPath();
ctx1.fillStyle = "cornflowerblue";
ctx1.strokeStyle = "cornflowerblue";
ctx1.moveTo(0,480);
ctx1.lineTo(62,480);
ctx1.lineTo(62,540);
ctx1.lineTo(160,540);
ctx1.lineTo(160,600);
ctx1.lineTo(0,600);
ctx1.fill();
ctx1.stroke();
ctx1.closePath();

ctx1.beginPath();
ctx1.fillStyle = "cornflowerblue";
ctx1.strokeStyle = "cornflowerblue";
ctx1.arc(150,602,63,1*Math.PI,2*Math.PI);
ctx1.fill();
ctx1.stroke();
ctx1.closePath();


ctx1.beginPath();
ctx1.fillStyle = "orange";
ctx1.strokeStyle = "orange";
ctx1.moveTo(220,325);
ctx1.lineTo(295,240);
ctx1.lineTo(370,325);
ctx1.fill();
ctx1.stroke();
ctx1.closePath();




let canvas = document.getElementById("canvas");
let ctx2 = canvas.getContext("2d");


ctx2.beginPath();
ctx2.fillStyle = 'blue';
ctx2.fillRect(0,0,60,60);
ctx2.closePath();

ctx2.beginPath();
ctx2.fillStyle = 'black';
ctx2.fillRect(320,360,80,40);
ctx2.closePath();

ctx2.beginPath();
ctx2.fillStyle = 'black';
ctx2.fillRect(360,320,40,80);
ctx2.closePath();


ctx2.beginPath();
ctx2.strokeStyle = 'blue';
ctx2.moveTo(60,60);
ctx2.lineTo(200,200);
ctx2.stroke();
ctx2.closePath();

ctx2.beginPath();
ctx2.strokeStyle = 'red';
ctx2.moveTo(400,0);
ctx2.lineTo(200,200);
ctx2.stroke();
ctx2.closePath();

ctx2.beginPath();
ctx2.fillStyle = 'yellow';
ctx2.fillRect(0,360,80,40);
ctx2.closePath();

ctx2.beginPath();
ctx2.fillStyle = 'lightblue';
ctx2.fillRect(0,160,40,80);
ctx2.closePath();

ctx2.beginPath();
ctx2.fillStyle = 'lightblue';
ctx2.fillRect(360,180,40,40);
ctx2.closePath();

ctx2.beginPath();
ctx2.fillStyle = 'yellow';
ctx2.fillRect(0,320,40,80);
ctx2.closePath();

ctx2.beginPath();
ctx2.fillStyle = 'red';
ctx2.fillRect(340,0,60,60);
ctx2.closePath();

ctx2.beginPath();
ctx2.fillStyle = 'red';
ctx2.fillRect(140,200,60,60);
ctx2.closePath();


ctx2.beginPath();
ctx2.strokeStyle = 'green';
ctx2.moveTo(0,200);
ctx2.lineTo(400,200);
ctx2.stroke();
ctx2.closePath();

ctx2.beginPath();
ctx2.strokeStyle = 'green';
ctx2.moveTo(200,200);
ctx2.lineTo(200,340);
ctx2.stroke();
ctx2.closePath();


ctx2.beginPath();
ctx2.fillStyle = 'lightblue';
ctx2.strokeStyle = 'green';
ctx2.arc(200,400,60,1*Math.PI,0);
ctx2.fill();
ctx2.stroke();
ctx2.closePath();

ctx2.beginPath();
ctx2.strokeStyle = 'green';
ctx2.arc(200,400,100,1*Math.PI,1.5*Math.PI);
ctx2.stroke();
ctx2.closePath();

ctx2.beginPath();
ctx2.strokeStyle = 'green';
ctx2.arc(200,400,80,1.5*Math.PI,0);
ctx2.stroke();
ctx2.closePath();

ctx2.beginPath();
ctx2.strokeStyle = 'green';
ctx2.arc(200,200,120,1.75*Math.PI,0);
ctx2.stroke();
ctx2.closePath();


ctx2.beginPath();
ctx2.fillStyle = 'lightblue';
ctx2.strokeStyle = 'blue';
ctx2.arc(200,150,20,0,2*Math.PI);
ctx2.fill();
ctx2.stroke();
ctx2.closePath();

ctx2.beginPath();
ctx2.fillStyle = 'yellow';
ctx2.strokeStyle = 'green';
ctx2.arc(100,300,20,0,2*Math.PI);
ctx2.fill();
ctx2.stroke();
ctx2.closePath();

ctx2.beginPath();
ctx2.fillStyle = 'yellow';
ctx2.strokeStyle = 'green';
ctx2.arc(300,300,20,0,2*Math.PI);
ctx2.fill();
ctx2.stroke();
ctx2.closePath();

ctx2.beginPath();
ctx2.strokeStyle = 'green';
ctx2.arc(200,200,90,1*Math.PI,0);
ctx2.stroke();
ctx2.closePath();

ctx2.beginPath();
ctx2.strokeStyle = 'green';
ctx2.arc(200,200,120,1*Math.PI,1.25*Math.PI);
ctx2.stroke();
ctx2.closePath();