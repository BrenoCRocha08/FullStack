/* =========================================================
   ui.js
   - Responsável por ligar botões/elementos do HTML com
     o estado do jogo. Separar UI ajuda a organização.
========================================================= */

function atualizarHUD(estado) {
  document.getElementById("hudOnda").textContent = estado.ondaAtual;
  document.getElementById("hudVidas").textContent = estado.vidas;
  document.getElementById("hudDinheiro").textContent = estado.dinheiro;
  document.getElementById("hudSelecao").textContent = estado.torreSelecionada ? estado.torreSelecionada : "Nenhuma";
  document.getElementById("hudStatus").textContent = estado.statusTexto;
}

function configurarBotoes(estado, pegarAgoraMs) {
  // Botão: iniciar jogo (reset e ativa)
  document.getElementById("btnIniciarJogo").addEventListener("click", () => {
    estado.iniciarJogo();
    atualizarHUD(estado);
  });

  // Botão: iniciar onda
  document.getElementById("btnIniciarOnda").addEventListener("click", () => {
    estado.iniciarOnda(pegarAgoraMs());
    atualizarHUD(estado);
  });

  // Seleção de torre básica
  document.getElementById("btnTorreBasica").addEventListener("click", () => {
    estado.torreSelecionada = "basica";
    estado.statusTexto = "Varelinha Básica selecionada. Clique no mapa para construir.";
    atualizarHUD(estado);
  });

  // Seleção de torre lenta
  document.getElementById("btnTorreLenta").addEventListener("click", () => {
    estado.torreSelecionada = "lenta";
    estado.statusTexto = "Varelinha Gelado selecionada. Clique no mapa para construir.";
    atualizarHUD(estado);
  });

  // Atalhos de teclado (ajuda a jogabilidade e deixa mais "completo")
  window.addEventListener("keydown", (e) => {
    if (e.code === "Space") {
      estado.iniciarOnda(pegarAgoraMs());
      atualizarHUD(estado);
      e.preventDefault();
    }
    if (e.key.toLowerCase() === "r") {
      estado.iniciarJogo();
      atualizarHUD(estado);
    }
  });
}