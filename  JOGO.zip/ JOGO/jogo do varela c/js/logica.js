/* =========================================================
   logica.js
   - Regras do jogo: mapa, caminho, ondas, dinheiro, vidas,
     validação de posicionamento.
   - A ideia é deixar a "engine" separada da interface.
========================================================= */

// Converte tile (coluna, linha) para coordenada do centro em pixels
function tileParaCentro(tileX, tileY) {
  return {
    x: tileX * CONFIG.TAM_TILE + CONFIG.TAM_TILE / 2,
    y: tileY * CONFIG.TAM_TILE + CONFIG.TAM_TILE / 2
  };
}

// Cria o caminho do inimigo em tiles (lista de pontos).
// Você pode explicar assim: "o inimigo segue uma lista de pontos do mapa".
function criarCaminhoPadrao() {
  // caminho em tiles: (x,y) na grade
  const tiles = [
    {x: 0, y: 4}, {x: 3, y: 4}, {x: 3, y: 2}, {x: 7, y: 2},
    {x: 7, y: 7}, {x: 11, y: 7}, {x: 11, y: 4}, {x: 15, y: 4}
  ];

  // converte tiles para pontos em pixels (centro do tile)
  return tiles.map(t => tileParaCentro(t.x, t.y));
}

// Gera uma grade booleana dizendo onde é caminho (true = é caminho)
function gerarMascaraCaminho(caminhoTiles) {
  const mascara = [];
  for (let y = 0; y < CONFIG.LINHAS; y++) {
    mascara[y] = [];
    for (let x = 0; x < CONFIG.COLUNAS; x++) {
      mascara[y][x] = false;
    }
  }

  // Marca os tiles do caminho como true
  for (const t of caminhoTiles) {
    if (t.y >= 0 && t.y < CONFIG.LINHAS && t.x >= 0 && t.x < CONFIG.COLUNAS) {
      mascara[t.y][t.x] = true;
    }
  }
  return mascara;
}

class EstadoJogo {
  constructor() {
    // caminho em tiles e em pontos
    this.caminhoTiles = [
      {x: 0, y: 4}, {x: 1, y: 4}, {x: 2, y: 4}, {x: 3, y: 4},
      {x: 3, y: 3}, {x: 3, y: 2},
      {x: 4, y: 2}, {x: 5, y: 2}, {x: 6, y: 2}, {x: 7, y: 2},
      {x: 7, y: 3}, {x: 7, y: 4}, {x: 7, y: 5}, {x: 7, y: 6}, {x: 7, y: 7},
      {x: 8, y: 7}, {x: 9, y: 7}, {x: 10, y: 7}, {x: 11, y: 7},
      {x: 11, y: 6}, {x: 11, y: 5}, {x: 11, y: 4},
      {x: 12, y: 4}, {x: 13, y: 4}, {x: 14, y: 4}, {x: 15, y: 4}
    ];

    this.caminhoPontos = criarCaminhoPadrao();
    this.mascaraCaminho = gerarMascaraCaminho(this.caminhoTiles);

    this.resetar();
  }

  resetar() {
    this.inimigos = [];
    this.torres = [];
    this.projeteis = [];

    this.vidas = CONFIG.VIDAS_INICIAIS;
    this.dinheiro = CONFIG.DINHEIRO_INICIAL;
    this.ondaAtual = 0;

    this.jogoAtivo = false;
    this.ondaEmAndamento = false;

    // Controle de spawn de inimigos
    this.inimigosParaSpawnar = 0;
    this.proximoSpawnEm = 0;

    // Torre selecionada para construir
    this.torreSelecionada = null; // "basica" | "lenta" | null

    // Status geral
    this.statusTexto = "Aguardando iniciar";
  }

  podeColocarTorre(tileX, tileY) {
    // 1) fora do mapa
    if (tileX < 0 || tileX >= CONFIG.COLUNAS || tileY < 0 || tileY >= CONFIG.LINHAS) return false;

    // 2) não pode no caminho
    if (this.mascaraCaminho[tileY][tileX]) return false;

    // 3) não pode em cima de outra torre
    for (const t of this.torres) {
      if (t.tileX === tileX && t.tileY === tileY) return false;
    }
    return true;
  }

  tentarConstruirTorre(tileX, tileY) {
    if (!this.torreSelecionada) {
      this.statusTexto = "Selecione um tipo de torre primeiro";
      return false;
    }

    if (!this.podeColocarTorre(tileX, tileY)) {
      this.statusTexto = "Não é possível construir aqui (caminho/ocupado/fora)";
      return false;
    }

    const cfg = CONFIG.TORRES[this.torreSelecionada];
    if (this.dinheiro < cfg.custo) {
      this.statusTexto = "Dinheiro insuficiente";
      return false;
    }

    this.dinheiro -= cfg.custo;
    this.torres.push(new Torre(tileX, tileY, this.torreSelecionada));
    this.statusTexto = `${cfg.nome} construída!`;
    return true;
  }

  iniciarJogo() {
    this.resetar();
    this.jogoAtivo = true;
    this.statusTexto = "Jogo iniciado! Selecione torres e construa.";
  }

  iniciarOnda(agoraMs) {
    if (!this.jogoAtivo) {
      this.statusTexto = "Clique em 'Iniciar Jogo' primeiro";
      return;
    }
    if (this.ondaEmAndamento) {
      this.statusTexto = "A onda já está em andamento";
      return;
    }
    if (this.ondaAtual >= CONFIG.MAX_ONDAS) {
      this.statusTexto = "Você já completou todas as ondas!";
      return;
    }

    this.ondaAtual++;
    this.ondaEmAndamento = true;

    // Quantidade de inimigos cresce por onda
    this.inimigosParaSpawnar = CONFIG.INIMIGOS_BASE + (this.ondaAtual - 1) * CONFIG.INIMIGOS_POR_ONDA;
    this.proximoSpawnEm = agoraMs;

    this.statusTexto = `Onda ${this.ondaAtual} iniciada!`;
  }

  spawnarInimigo() {
    // Vida e velocidade crescem levemente por onda (balanceamento simples)
    const vida = CONFIG.INIMIGO.vidaBase + (this.ondaAtual - 1) * CONFIG.INIMIGO.vidaPorOnda;
    const vel = CONFIG.INIMIGO.velocidadeBase + (this.ondaAtual - 1) * CONFIG.INIMIGO.velocidadePorOnda;

    this.inimigos.push(new Inimigo(this.caminhoPontos, vida, vel));
  }

  atualizar(dt, agoraMs) {
    if (!this.jogoAtivo) return;

    // Spawner de inimigos durante a onda
    if (this.ondaEmAndamento) {
      if (this.inimigosParaSpawnar > 0 && agoraMs >= this.proximoSpawnEm) {
        this.spawnarInimigo();
        this.inimigosParaSpawnar--;
        this.proximoSpawnEm = agoraMs + CONFIG.INTERVALO_SPAWN_MS;
      }

      // Se não tem mais pra spawnar e não tem inimigos vivos, termina onda
      const algumVivo = this.inimigos.some(i => i.ativo);
      if (this.inimigosParaSpawnar === 0 && !algumVivo) {
        this.ondaEmAndamento = false;

        if (this.ondaAtual >= CONFIG.MAX_ONDAS) {
          this.statusTexto = "Parabéns! Você venceu todas as ondas!";
          this.jogoAtivo = false; // encerra
        } else {
          this.statusTexto = "Onda concluída! Construa mais torres e inicie a próxima.";
        }
      }
    }

    // Atualiza inimigos
    for (const ini of this.inimigos) {
      if (!ini.ativo) continue;
      ini.atualizar(dt, agoraMs);

      // Chegou no fim do caminho?
      // Se indiceAlvo for o último ponto (caminhoPontos.length - 1), então alcançou a base.
      if (ini.indiceAlvo >= this.caminhoPontos.length - 1) {
        ini.ativo = false;
        this.vidas -= CONFIG.INIMIGO.danoNaBase;
        this.statusTexto = "Um inimigo chegou na base!";

        if (this.vidas <= 0) {
          this.vidas = 0;
          this.statusTexto = "Fim de jogo! (vidas = 0)";
          this.jogoAtivo = false;
        }
      }

      // Morreu?
      if (ini.ativo && ini.vida <= 0) {
        ini.ativo = false;
        this.dinheiro += CONFIG.INIMIGO.recompensa;
      }
    }

    // Atualiza torres (disparam e criam projéteis)
    for (const t of this.torres) {
      t.atualizar(agoraMs, this.inimigos, this.projeteis);
    }

    // Atualiza projéteis
    for (const p of this.projeteis) {
      p.atualizar(dt, agoraMs);
    }

    // Remove projéteis inativos (limpeza)
    this.projeteis = this.projeteis.filter(p => p.ativo);
  }

  desenhar(ctx, tileHover = null) {
    // Fundo
    ctx.clearRect(0, 0, CONFIG.LARGURA, CONFIG.ALTURA);

    // Desenha grade
    for (let y = 0; y < CONFIG.LINHAS; y++) {
      for (let x = 0; x < CONFIG.COLUNAS; x++) {
        const px = x * CONFIG.TAM_TILE;
        const py = y * CONFIG.TAM_TILE;

        // caminho tem uma cor diferente
        if (this.mascaraCaminho[y][x]) {
          ctx.fillStyle = "rgba(32, 136, 41, 0.69)";
          ctx.fillRect(px, py, CONFIG.TAM_TILE, CONFIG.TAM_TILE);
        }

        ctx.strokeStyle = "hsla(39, 72%, 25%, 0.09)";
        ctx.strokeRect(px, py, CONFIG.TAM_TILE, CONFIG.TAM_TILE);
      }
    }

    // Destaque onde o mouse está (para ajudar a jogar)
    if (tileHover) {
      const { tx, ty } = tileHover;
      if (tx >= 0 && tx < CONFIG.COLUNAS && ty >= 0 && ty < CONFIG.LINHAS) {
        const pode = this.podeColocarTorre(tx, ty);
        ctx.fillStyle = pode ? "rgba(89, 193, 211, 0.92)" : "rgba(255, 92, 92, 0.53)";
        ctx.fillRect(tx * CONFIG.TAM_TILE, ty * CONFIG.TAM_TILE, CONFIG.TAM_TILE, CONFIG.TAM_TILE);
      }
    }

    // Desenha torres
    for (const t of this.torres) {
      t.desenhar(ctx, false);
    }

    // Desenha projéteis
    for (const p of this.projeteis) {
      p.desenhar(ctx);
    }

    // Desenha inimigos
    for (const ini of this.inimigos) {
      ini.desenhar(ctx);
    }


   if (!this._imgBase) {
      this._imgBase = new Image();
      this._imgBase.src = "js/moto.png"; 
    }
    
    const fim = this.caminhoPontos[this.caminhoPontos.length - 1];

    if (this._imgBase.complete && this._imgBase.naturalWidth > 0) {
      ctx.drawImage(this._imgBase, fim.x - 26, fim.y - 50, 122, 122);
    } else {
      // fallback enquanto carrega
      ctx.fillStyle = "rgba(255,255,255,0.10)";
      ctx.fillRect(fim.x - 22, fim.y - 22, 44, 44);
      ctx.fillStyle = "rgba(255,255,255,0.70)";
      ctx.font = "12px Arial";
      ctx.fillText("BASE", fim.x - 16, fim.y + 4);
    }
} }