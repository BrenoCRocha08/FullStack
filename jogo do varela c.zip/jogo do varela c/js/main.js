/* =========================================================
   main.js
   - Ponto de entrada: pega canvas, cria estado, loop principal,
     eventos de mouse para construir torre.
========================================================= */

const canvas = document.getElementById("tela");
const ctx = canvas.getContext("2d");

// garante dimensões conforme config
canvas.width = CONFIG.LARGURA;
canvas.height = CONFIG.ALTURA;

const estado = new EstadoJogo();

let ultimoTempo = performance.now();
let tileHover = null;

// Função para pegar "agora" em ms (usada pela UI)
function pegarAgoraMs() {
  return performance.now();
}

// Configura botões e HUD inicial
configurarBotoes(estado, pegarAgoraMs);
atualizarHUD(estado);

// Converte posição do mouse (px) para tile (inteiro)
function mouseParaTile(mx, my) {
  const tx = Math.floor(mx / CONFIG.TAM_TILE);
  const ty = Math.floor(my / CONFIG.TAM_TILE);
  return { tx, ty };
}

// Evento: mover mouse (para mostrar highlight no tile)
canvas.addEventListener("mousemove", (e) => {
  const rect = canvas.getBoundingClientRect();
  const mx = (e.clientX - rect.left) * (canvas.width / rect.width);
  const my = (e.clientY - rect.top) * (canvas.height / rect.height);
  tileHover = mouseParaTile(mx, my);
});

// Evento: clique para construir torre
canvas.addEventListener("click", (e) => {
  const rect = canvas.getBoundingClientRect();
  const mx = (e.clientX - rect.left) * (canvas.width / rect.width);
  const my = (e.clientY - rect.top) * (canvas.height / rect.height);

  const { tx, ty } = mouseParaTile(mx, my);

  // Só tenta construir se o jogo estiver ativo
  if (!estado.jogoAtivo) {
    estado.statusTexto = "Clique em 'Iniciar Jogo' para começar";
    atualizarHUD(estado);
    return;
  }

  estado.tentarConstruirTorre(tx, ty);
  atualizarHUD(estado);
});

// Loop do jogo (update + draw)
function loop(tempoAtual) {
  const dt = (tempoAtual - ultimoTempo) / 1000; // em segundos
  ultimoTempo = tempoAtual;

  estado.atualizar(dt, tempoAtual);
  estado.desenhar(ctx, tileHover);

  // HUD atualiza sempre (status, dinheiro etc.)
  atualizarHUD(estado);

  requestAnimationFrame(loop);
}

requestAnimationFrame(loop);