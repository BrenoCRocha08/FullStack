/* =========================================================
   entidades.js
   - Define classes principais: Inimigo, Torre, Projetil.
   - Separar em arquivo ajuda a organização e explicação.
========================================================= */

class Inimigo {
  constructor(caminhoPontos, vida, velocidade) {
    // Caminho é uma lista de pontos (x,y). O inimigo vai indo de um para outro.
    this.caminho = caminhoPontos;
    this.indiceAlvo = 0;

    // Começa no primeiro ponto do caminho
    this.x = this.caminho[0].x;
    this.y = this.caminho[0].y;

    this.vidaMax = vida;
    this.vida = vida;

    // velocidade em px/s (por segundo)
    this.velocidadeBase = velocidade;
    this.velocidadeAtual = velocidade;

    // Controle de lentidão (slow)
    this.fimLentidaoEm = 0;

    this.ativo = true; // se morreu ou chegou na base, deixa de estar ativo
  }

  aplicarLentidao(fator, duracaoMs, agoraMs) {
    // Aplica slow e define até quando dura
    this.velocidadeAtual = this.velocidadeBase * fator;
    this.fimLentidaoEm = agoraMs + duracaoMs;
  }

  atualizar(dt, agoraMs) {
    // dt = delta time em segundos (ex.: 0.016)
    if (!this.ativo) return;

    // Se lentidão expirou, volta velocidade
    if (this.fimLentidaoEm > 0 && agoraMs > this.fimLentidaoEm) {
      this.velocidadeAtual = this.velocidadeBase;
      this.fimLentidaoEm = 0;
    }

    // Pega o próximo ponto alvo do caminho
    const alvo = this.caminho[this.indiceAlvo + 1];
    if (!alvo) return; // sem alvo significa que já está no fim (tratado fora)

    const dx = alvo.x - this.x;
    const dy = alvo.y - this.y;
    const dist = Math.hypot(dx, dy);

    // Se estiver muito perto do ponto, "encaixa" e avança pro próximo
    const passo = this.velocidadeAtual * dt;

    if (dist <= passo) {
      this.x = alvo.x;
      this.y = alvo.y;
      this.indiceAlvo++;
    } else {
      // Move na direção normalizada
      this.x += (dx / dist) * passo;
      this.y += (dy / dist) * passo;
    }
  }

  desenhar(ctx) {
    if (!this.ativo) return;

    // corpo do inimigo
    ctx.beginPath();
    ctx.fillStyle = "#ff5c5c";
    ctx.arc(this.x, this.y, CONFIG.INIMIGO.raio, 0, Math.PI * 2);
    ctx.fill();

    // barra de vida (simples)
    const w = 34;
    const h = 6;
    const px = this.x - w / 2;
    const py = this.y - CONFIG.INIMIGO.raio - 12;

    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillRect(px, py, w, h);

    ctx.fillStyle = "#59d36a";
    const perc = Math.max(0, this.vida / this.vidaMax);
    ctx.fillRect(px, py, w * perc, h);

    // indicador visual se estiver lento
    if (this.fimLentidaoEm > 0) {
      ctx.fillStyle = "rgba(88, 166, 255, 0.35)";
      ctx.beginPath();
      ctx.arc(this.x, this.y, CONFIG.INIMIGO.raio + 6, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

class Torre {
  constructor(tileX, tileY, tipo) {
    // tileX, tileY são coordenadas na grade (inteiros)
    this.tileX = tileX;
    this.tileY = tileY;

    // converte tile para centro em px
    const centro = tileParaCentro(tileX, tileY);
    this.x = centro.x;
    this.y = centro.y;

    this.tipo = tipo; // "basica" ou "lenta"
    const cfg = CONFIG.TORRES[tipo];

    this.alcance = cfg.alcance;
    this.dano = cfg.dano;
    this.tempoRecarga = cfg.tempoRecarga;
    this.cor = cfg.cor;

    this.tipoEfeito = cfg.tipoEfeito;
    this.fatorLentidao = cfg.fatorLentidao || 1;
    this.duracaoLentidao = cfg.duracaoLentidao || 0;

    // Quando pode atirar de novo?
    this.proximoTiroEm = 0;
  }

  procurarAlvo(inimigos) {
    // Estratégia simples: pega o primeiro inimigo que estiver dentro do alcance
    for (const ini of inimigos) {
      if (!ini.ativo) continue;
      const d = Math.hypot(ini.x - this.x, ini.y - this.y);
      if (d <= this.alcance) return ini;
    }
    return null;
  }

  atualizar(agoraMs, inimigos, projeteis) {
    // Se ainda não está na hora de atirar, sai
    if (agoraMs < this.proximoTiroEm) return;

    const alvo = this.procurarAlvo(inimigos);
    if (!alvo) return;

    // Cria um projétil que vai até o alvo
    projeteis.push(new Projetil(this.x, this.y, alvo, this.dano, this.tipoEfeito, this.fatorLentidao, this.duracaoLentidao));

    // Agenda próximo tiro
    this.proximoTiroEm = agoraMs + this.tempoRecarga;
  }

  desenhar(ctx, selecionada = false) {
    // Base da torre (quadradinho)
    ctx.fillStyle = this.cor;
    ctx.fillRect(this.x - 16, this.y - 16, 32, 32);

    // Detalhe
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.fillRect(this.x - 16, this.y - 16, 32, 10);

    // Se selecionada, desenha alcance
    if (selecionada) {
      ctx.beginPath();
      ctx.strokeStyle = "rgba(255,255,255,0.25)";
      ctx.lineWidth = 2;
      ctx.arc(this.x, this.y, this.alcance, 0, Math.PI * 2);
      ctx.stroke();
    }
  }
}

class Projetil {
  constructor(x, y, alvo, dano, tipoEfeito, fatorLentidao, duracaoLentidao) {
    this.x = x;
    this.y = y;
    this.alvo = alvo;

    this.dano = dano;
    this.tipoEfeito = tipoEfeito;
    this.fatorLentidao = fatorLentidao;
    this.duracaoLentidao = duracaoLentidao;

    this.velocidade = 360; // px/s
    this.ativo = true;
  }

  atualizar(dt, agoraMs) {
    if (!this.ativo) return;
    if (!this.alvo || !this.alvo.ativo) {
      // se perdeu o alvo, some
      this.ativo = false;
      return;
    }

    const dx = this.alvo.x - this.x;
    const dy = this.alvo.y - this.y;
    const dist = Math.hypot(dx, dy);

    const passo = this.velocidade * dt;

    if (dist <= passo) {
      // Acertou!
      this.x = this.alvo.x;
      this.y = this.alvo.y;

      // Tira vida
      this.alvo.vida -= this.dano;

      // Aplica efeito slow se for o caso
      if (this.tipoEfeito === "lento") {
        this.alvo.aplicarLentidao(this.fatorLentidao, this.duracaoLentidao, agoraMs);
      }

      this.ativo = false;
    } else {
      this.x += (dx / dist) * passo;
      this.y += (dy / dist) * passo;
    }
  }

  desenhar(ctx) {
    if (!this.ativo) return;

    ctx.beginPath();
    ctx.fillStyle = (this.tipoEfeito === "lento") ? "#58a6ff" : "#f2e85e";
    ctx.arc(this.x, this.y, 5, 0, Math.PI * 2);
    ctx.fill();
  }
}