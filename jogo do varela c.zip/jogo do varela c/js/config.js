/* =========================================================
   config.js
   - Centraliza configurações do jogo (tamanho de tile, cores,
     custos, balanceamento). Facilita explicar e ajustar.
========================================================= */

const CONFIG = {
  // Canvas
  LARGURA: 900,
  ALTURA: 520,

  // Mapa em grade (tiles)
  TAM_TILE: 52, // tamanho de cada quadrado da grade (px)
  COLUNAS: 16,  // 16 * 52 = 832 (vai sobrar margem no canvas)
  LINHAS: 10,   // 10 * 52 = 520 (bate a altura do canvas)

  // Economia e vidas
  VIDAS_INICIAIS: 20,
  DINHEIRO_INICIAL: 120,

  // Ondas
  MAX_ONDAS: 10,
  INIMIGOS_BASE: 6, // inimigos na onda 1
  INIMIGOS_POR_ONDA: 2, // incremento por onda
  INTERVALO_SPAWN_MS: 650, // tempo entre spawns na mesma onda

  // Torres (valores simples para "cara de trabalho de estudante")
  TORRES: {
    basica: {
      nome: "Torre Básica",
      custo: 50,
      alcance: 115,
      dano: 14,
      tempoRecarga: 420, // ms
      cor: "#59d36a",
      tipoEfeito: "normal"
    },
    lenta: {
      nome: "Torre Lenta",
      custo: 80,
      alcance: 105,
      dano: 8,
      tempoRecarga: 520,
      cor: "#58a6ff",
      tipoEfeito: "lento",
      fatorLentidao: 0.60, // inimigo fica com 60% da velocidade
      duracaoLentidao: 900 // ms
    }
  },

  // Inimigos
  INIMIGO: {
    vidaBase: 55,
    vidaPorOnda: 12,
    velocidadeBase: 55, // px por segundo
    velocidadePorOnda: 1.5,
    recompensa: 12,
    danoNaBase: 1,
    raio: 14
  }
};
